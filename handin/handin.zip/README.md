To train and generate the test submission place the data (eval.npz and train npz) in the /data folder and run `python histone.py -T data/train.npz -t data/eval.npz`.
